
package Modelo.Implementaciones;

import Modelo.Paciente;

public class Servicio_Atencion {
    public String EstablecerArea_Elegida(Paciente usuario){
        return usuario.getArea_Atencion();
    }
    public String Responder_consulta(Paciente usuario){
        String area=EstablecerArea_Elegida(usuario);
        switch(area.toLowerCase()){
            case "nutricion" -> {
                return "El area de nutricion se encarga de guiar al paciente en buen habitos alimenticios."
                        + "Atienden los lunes,miercoles y viernes de 8am  a 1pm.";
            }
            case "psicologia" -> {
                return "Area relacionada al cuidado de la salud mental de manera conductual y cognitiva."
                        + "No confundir con psiquiatria.Atendemos los sabados y domingos de 8am a 1pm";
            }
            case "odontologia" -> {
                return "Area encargada del cuidado dental de las personas.Atendemos los martes, jueves y sabados"
                        + "de 2pm a 6pm";
            }
            default -> {
                return "Area no registrada o existente aqui.";
            }
    }
    }      
}
