
package Modelo.Implementaciones;

import Modelo.Medico_Especialista;
import Modelo.Paciente;

public class Servicio_Consulta_medica {
    public String pagarConsulta(Paciente usuario,Medico_Especialista med1){
        String frase="El monto a pagar por el area de "+usuario.getArea_Atencion()+" es ";
        return frase;
    }
}
