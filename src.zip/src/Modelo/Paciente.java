
package Modelo;

import Modelo.Implementaciones.Evaluarsalud;
import Modelo.Interfaces.IngresarDatos;
/*Aqui se usa el Prototype mediante la interfaz Cloneable*/
public class Paciente extends Evaluarsalud implements Cloneable,IngresarDatos {
    
    private String nombres;
    private String apellidos;
    private String dni;
    private int edad;
    private double peso;
    private String genero;
    private double altura;
    private String habitos;
    private String Area_Atencion;

    // Constructor
    public Paciente(String nombres, String apellidos, String dni, int edad, double peso, String genero, double altura, String habitos) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.dni = dni;
        this.edad = edad;
        this.peso = peso;
        this.genero = genero;
        this.altura = altura;
        this.habitos = habitos;
    }
    public Paciente() {
    }
    public Paciente(String dni) {
        this.dni = dni;
    }
    public void setNombres(String nombres) {this.nombres = nombres;}
    public void setApellidos(String apellidos) {this.apellidos = apellidos;}
    public void setDni(String dni) {this.dni = dni;}
    public void setEdad(int edad) {this.edad = edad;}
    public void setPeso(double peso) {this.peso = peso;}
    public void setGenero(String genero) {this.genero = genero;}
    public void setAltura(double altura) {this.altura = altura;}
    public void setHabitos(String habitos) {this.habitos = habitos;}
    public String getArea_Atencion() { return Area_Atencion; }
    public void setArea_Atencion(String Area_Atencion) {this.Area_Atencion = Area_Atencion;}
    public String getDni() {return dni;}
    public String getNombres() { return nombres; }
    public String getApellidos() { return apellidos; }
    public String getGenero() { return genero; }
    public int getEdad() { return edad; }
    public double getPeso() { return peso; }
    public double getAltura() { return altura; }
    public String getHabitos() { return habitos; }

    // Método ingresarDatos
    @Override
    public void ingresarDatos() {
        System.out.println("El usuario ha ingresado sus datos los cuales son:");
        System.out.println("Nombre: " + getNombres() + " " + getApellidos());
        System.out.println("Edad: " + getEdad() + " años");
        System.out.println("Peso: " + getPeso() + " kg");
        System.out.println("Altura: " + getAltura() + " metros");
        System.out.println("Habitos: " + getHabitos());
    }
  /*Metodo Prototype para clonar al objeto proveniente de paciente*/
     @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

  }

