
package Vista;

import Controlador.CRUDCita;
import Controlador.CitaFactory;
import Modelo.Cita;
import Modelo.DAO.DBConnection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
public class Confirmar_Cita extends javax.swing.JFrame {
    private Runnable siguiente;
    private Cita cita;
    
    ajustedeImangen ajusto = new ajustedeImangen();
    
    public Confirmar_Cita(Cita cita) {
        initComponents();
        /*ajusto.escalarLabel(imagen1, "/Imagenes/logo saludformaaaa.jpg" );*/
        setTitle("Ventana 2");
        this.cita=cita;
        comboDoctores.setEnabled(false); // al iniciar
        comboHoras.setEnabled(false);
        java.util.Date fecha_hoy=new java.util.Date();
        Calendario_Cita.setMinSelectableDate(fecha_hoy);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        comboCita = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        comboArea = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        comboDoctores = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        comboHoras = new javax.swing.JComboBox<>();
        SiguienteButton = new javax.swing.JToggleButton();
        BtnRegresar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        imagen1 = new javax.swing.JLabel();
        Calendario_Cita = new com.toedter.calendar.JCalendar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jLabel1.setText("Seleccione la fecha de la cita:");

        jLabel5.setText("Ingresa la cita que quieres realizar:");

        comboCita.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "General", "Control", "Síntoma en Específico" }));

        jLabel3.setText("Seleccione el Area a Elegir:");

        comboArea.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Oncologia", "Neurologia", "Gastroenterologia", "Hepatologia", "Medicina General" }));
        comboArea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboAreaActionPerformed(evt);
            }
        });

        jLabel4.setText("Seleccione el doctor que quiera que le atienda:");

        comboDoctores.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboDoctores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboDoctoresActionPerformed(evt);
            }
        });

        jLabel2.setText("Seleccione la Hora:");

        comboHoras.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00" }));

        SiguienteButton.setBackground(new java.awt.Color(204, 204, 204));
        SiguienteButton.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        SiguienteButton.setText("Siguiente");
        SiguienteButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SiguienteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SiguienteButtonActionPerformed(evt);
            }
        });

        BtnRegresar.setBackground(new java.awt.Color(204, 204, 204));
        BtnRegresar.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        BtnRegresar.setText("Regresar  ");
        BtnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnRegresar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegresarActionPerformed(evt);
            }
        });

        jLabel6.setBackground(new java.awt.Color(255, 204, 204));
        jLabel6.setForeground(new java.awt.Color(255, 0, 0));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("¡No olvides establecer una fecha!");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(comboCita, 0, 313, Short.MAX_VALUE)
                            .addComponent(comboArea, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(318, 318, 318))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(comboDoctores, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(SiguienteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(44, 44, 44)
                                        .addComponent(BtnRegresar))
                                    .addComponent(comboHoras, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(imagen1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel1)
                        .addGap(112, 112, 112)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(Calendario_Cita, javax.swing.GroupLayout.PREFERRED_SIZE, 449, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Calendario_Cita, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(comboCita, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(comboArea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(comboDoctores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(comboHoras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SiguienteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BtnRegresar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(imagen1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void setSiguiente(Runnable siguiente) {
    this.siguiente = siguiente;
    }
    public void cargarDoctoresPorArea(String area) {
    try {
        try (Connection con = DBConnection.getInstancia1().getConexion()) {
            CallableStatement cs = con.prepareCall("{CALL MostrarDoctoresPorArea(?)}");
            cs.setString(1, area);
            ResultSet rs = cs.executeQuery();
            comboDoctores.removeAllItems();
            while (rs.next()) {
                comboDoctores.addItem(rs.getString("NombreCompleto"));
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al cargar doctores desde el procedimiento: " + ex.getMessage());
    }
}
    private void comboAreaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboAreaActionPerformed
          Object seleccionado = comboArea.getSelectedItem();
          if (seleccionado != null) {
              String areaSeleccionada = seleccionado.toString();
              cargarDoctoresPorArea(areaSeleccionada);
              comboDoctores.setEnabled(true);
          }
    }//GEN-LAST:event_comboAreaActionPerformed

    private void comboDoctoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboDoctoresActionPerformed
         Object seleccionado = comboDoctores.getSelectedItem();
         if (seleccionado != null) {
            String doctorSeleccionado = seleccionado.toString();
            cargaHorasDisponibles(doctorSeleccionado);
            comboHoras.setEnabled(true);
         }
    }//GEN-LAST:event_comboDoctoresActionPerformed

    private void SiguienteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SiguienteButtonActionPerformed

        if(Calendario_Cita.getDate()==null){
            JOptionPane.showMessageDialog(null, "No puede avanzar porque le falta completar "
                    + "un espacio de texto",
                "Error al avanzar", JOptionPane.ERROR_MESSAGE);
        }
        else{
           double precio;
           String texto_Area=comboArea.getSelectedItem().toString();
           String DNI="";
      try {
          try (Connection con = DBConnection.getInstancia1().getConexion()) {
              CallableStatement cs = con.prepareCall("{CALL MostrarDNI(?)}");
              cs.setString(1, comboDoctores.getSelectedItem().toString());
              ResultSet rs = cs.executeQuery();
              while (rs.next()) {
                  DNI=rs.getString("DNI");
              }
          }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al cargar doctores desde el procedimiento: " + ex.getMessage());
    }
      cita.setDNI_Medico(DNI);
      cita.setArea_Elegida(texto_Area);
      cita.setFecha(obtenerFechaSeleccionada());
      cita.setHora(comboHoras.getSelectedItem().toString());
      cita.setEvaluacion_Realizada(comboCita.getSelectedItem().toString());
      if(cita.getArea_Elegida().equals("Neurologia") || cita.getArea_Elegida().equals("Oncologia")){
          precio=65.4;
      }
      else{
          precio=34;
      }
      cita.setPrecio(precio); 
      cita.setNombre_Completo_Medico(comboDoctores.getSelectedItem().toString());
        }
      this.dispose();
      siguiente.run();
       
    }//GEN-LAST:event_SiguienteButtonActionPerformed

    private void BtnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegresarActionPerformed
        /*Boton para regresar a la ventana principal*/
        this.setVisible(false);
        Confirmar_Cita v2=new Confirmar_Cita(cita);
        v2.setVisible(true);
        v2.setLocationRelativeTo(null);
    }//GEN-LAST:event_BtnRegresarActionPerformed
   /*Metodo para realizar una cita e insertar un registro de cita*/ 
    private void ConfirmarCita(){
      /*Comando para obtener el DNI del medico y usarlo en el setter*/
     CRUDCita operacion = CitaFactory.establecerOperacion("insertar", cita);
     int resultado = operacion.actuar(); 
       if (resultado > 0) {
        JOptionPane.showMessageDialog(this, "Cita realizada correctamente");
        this.dispose();
       } else {
        JOptionPane.showMessageDialog(this, "Error al realizar la cita");
       }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnRegresar;
    private com.toedter.calendar.JCalendar Calendario_Cita;
    private javax.swing.JToggleButton SiguienteButton;
    private javax.swing.JComboBox<String> comboArea;
    private javax.swing.JComboBox<String> comboCita;
    private javax.swing.JComboBox<String> comboDoctores;
    private javax.swing.JComboBox<String> comboHoras;
    private javax.swing.JLabel imagen1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

    public void cargaHorasDisponibles(String doctorSeleccionado) {
        try {
            try (Connection con = DBConnection.getInstancia1().getConexion() // Tu clase de conexión
            ) {
                CallableStatement cs = con.prepareCall("{CALL MostrarTurnoDoctor(?)}");
                cs.setString(1, doctorSeleccionado);
                ResultSet rs = cs.executeQuery();
                comboHoras.removeAllItems();
                while (rs.next()) {
                    if(rs.getString("Turno_Perteneciente").equals("Manana")){
                        comboHoras.addItem("08:00");
                        comboHoras.addItem("09:00");
                        comboHoras.addItem("10:00");
                        comboHoras.addItem("11:00");
                        comboHoras.addItem("12:00");
                    }
                    if(rs.getString("Turno_Perteneciente").equals("Tarde")){
                        comboHoras.addItem("14:00");
                        comboHoras.addItem("15:00");
                        comboHoras.addItem("16:00");
                        comboHoras.addItem("17:00");
                        comboHoras.addItem("18:00");
                    }
                }
            }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al cargar turnos desde el procedimiento: " + ex.getMessage());
    }
    }

    private Date obtenerFechaSeleccionada() {
       return new java.sql.Date(Calendario_Cita.getDate().getTime());
    }
}
