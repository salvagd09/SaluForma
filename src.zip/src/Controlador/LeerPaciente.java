
package Controlador;

import Modelo.DAO.PacienteDAO;
import Modelo.Paciente;

public class LeerPaciente implements CRUDPaciente  {
    private Paciente paciente;
    public LeerPaciente(Paciente paciente){
        this.paciente=paciente;
    }
    @Override
    public void actuar() {
       PacienteDAO pdao=new PacienteDAO();
       pdao.ejecutarCRUD("Mostrar",paciente);
    }
}
