
package Controlador;

import Modelo.Paciente;
import Modelo.DAO.PacienteDAO;
public class ActualizarPaciente implements CRUDPaciente {
    private Paciente paciente;
    public ActualizarPaciente(Paciente paciente){
        this.paciente=paciente;
    }
    @Override
    public void actuar() {
       PacienteDAO pdao=new PacienteDAO();
       int resultado=pdao.ejecutarCRUD("Actualizar",paciente);
       if(resultado==1){
           System.out.println("La actualizacion fue exitosa.");
           System.out.println("---------------------------");
       }else{
           System.out.println("La actualizacion no funciono.");
           System.out.println("---------------------------");
       }
    }
}
