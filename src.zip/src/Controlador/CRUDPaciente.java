
package Controlador;


public interface CRUDPaciente{
    void actuar();
}
