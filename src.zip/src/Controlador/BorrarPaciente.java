
package Controlador;
import Modelo.DAO.PacienteDAO;
import Modelo.Paciente;
public class BorrarPaciente implements CRUDPaciente {
    private Paciente paciente;
    public BorrarPaciente(Paciente paciente) {
        this.paciente = paciente;
    }
    @Override
    public void actuar() {
       PacienteDAO pdao=new PacienteDAO();
       int resultado=pdao.ejecutarCRUD("Eliminar",paciente);
       if(resultado==1){
           System.out.println("La eliminacion fue exitosa.");
       }else{
           System.out.println("La eliminacion no funciono.");
       }
    }
    
}
