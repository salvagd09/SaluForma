
package Controlador;

import Modelo.Paciente;
import Modelo.DAO.PacienteDAO;
public class RegistrarPaciente implements CRUDPaciente{
    private Paciente paciente;
    public RegistrarPaciente(Paciente paciente){
        this.paciente=paciente;
    }
    @Override
    public void actuar() {
       PacienteDAO pdao=new PacienteDAO();
       int resultado=pdao.ejecutarCRUD("Insertar",paciente);
       if(resultado==1){
           System.out.println("La insercion fue exitosa.");
       }else{
           System.out.println("La insercion no funcionó.");
       }
    }
}
